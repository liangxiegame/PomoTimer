


using Unity.UIWidgets.engine;
using Unity.UIWidgets.material;
using Unity.UIWidgets.widgets;


namespace SlidableExample
{
  public class Simple : UIWidgetsPanel
  {
    protected override Widget createWidget()
    {
      return new MaterialApp(
        title: "Flutter Slidable Demo",
        theme: new ThemeData(
          primarySwatch: Colors.blue
        ),
        home: new MyHomePage()
      );
    }
  }




  class MyHomePage : StatelessWidget {
    public override Widget build(BuildContext context)
    {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text("Flutter Slidable Demo")
      ),
      body: ListView.builder(
        itemCount: 100,
        itemBuilder: (context2, index)=> {
      return new Slidable(
               keynamename: ValueKey(index),
               actionPane: SlidableDrawerActionPane(),
               actions: < Widget >[
      IconSlideAction(
        caption: 'Archive',
        color: Colors.blue,
        icon: Icons.archive,
      ),
      IconSlideAction(
          caption: 'Share',
          color: Colors.indigo,
          icon: Icons.share,
        ),
        ],
      secondaryActions: <Widget >[
      IconSlideAction(
        caption: 'More',
        color: Colors.grey.shade200,
        icon: Icons.more_horiz,
      ),
      IconSlideAction(
          caption: 'Delete',
          color: Colors.red,
          icon: Icons.delete,
        ),
        ],
      dismissal:
      SlidableDismissal(
        child: SlidableDrawerDismissal(),
      ),
      child:
      ListTile(
          title: Text('$index'),
        ),
        );
    },
    ),
    );
  }
  }
}